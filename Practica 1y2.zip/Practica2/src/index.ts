let miNumero: number = 10; 

miNumero = 10 + 10; 
miNumero = 2.5;
console.log(miNumero);

let booleano: boolean = true;
booleano = false; 
// booleano = 3;  (Esto no es correcto)



let encendido: boolean; 
// console.log(encendido);
// Esto tambien es incorrecto
encendido = true; 
console.log("Encendido es: ", encendido); 
console.log("Encendido es: ", {encendido});


   //  = 1 y 0 
   encendido = false && true;
   encendido = false && false; 
   encendido = true && true; 

console.log("Resultado: ",encendido); 


let normal:any = "hola"; 
normal = 10; 
normal = true; 
normal = 11.25; 
console.log("Normal: ",normal); 


