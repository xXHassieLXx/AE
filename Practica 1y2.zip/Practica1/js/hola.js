var mensaje = 'Hola TS';
console.log(mensaje);
// var, let y const 
var numero = 10;
numero = 3.1426;
console.log(numero);
