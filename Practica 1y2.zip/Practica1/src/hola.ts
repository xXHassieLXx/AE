let mensaje:string = 'Hola TS';
console.log(mensaje);


// var, let y const 


let numero:number = 10; 
numero = 3.1426; 
console.log(numero);

